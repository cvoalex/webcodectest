# SyncTalk2D Multi-Model Fast Inference Service

A high-performance, real-time lip-sync generation service with dynamic model loading, Redis caching, and multi-model support.

## 🚀 Architecture Overview

This service provides a FastAPI-based REST API and WebSocket interface for real-time frame-by-frame lip-sync generation. It features automatic model downloading, extraction, and loading with comprehensive caching strategies.

### Key Features

- **🔄 Dynamic Model Loading**: Automatic model downloading and extraction from a central registry
- **📦 Multi-Model Support**: Load and manage multiple models simultaneously  
- **💾 Redis Caching**: High-performance frame and audio feature caching with model isolation
- **🌐 REST + WebSocket APIs**: Both traditional REST endpoints and real-time WebSocket streaming
- **🎵 Audio Override**: Per-request custom audio support with automatic feature extraction
- **📊 Comprehensive Monitoring**: Detailed performance statistics and health monitoring
- **🐳 Docker Ready**: Complete containerization support with Redis integration

## 📁 Project Structure

```
fast_service/
├── service.py                    # Main FastAPI application
├── multi_model_engine.py         # Core inference engine with multi-model support
├── dynamic_model_manager.py      # Automatic model downloading and management
├── multi_model_cache.py          # Redis caching with model isolation
├── inference_engine.py           # Single-model inference engine (legacy)
├── cache_manager.py              # Basic caching (legacy)
├── config.py                     # Service configuration
├── requirements.txt              # Python dependencies
├── Dockerfile                    # Container configuration
├── docker-compose.yml            # Multi-service orchestration
├── test_dynamic_loading.py       # Dynamic loading test suite
├── test_multi_model.py           # Multi-model test suite
├── models/                       # Local model storage
│   ├── model_name.zip            # Downloaded model packages
│   └── model_name/               # Extracted model directories
│       ├── video.mp4
│       ├── face_crops_328.mp4
│       ├── aud_ave.npy
│       ├── frame_index.json
│       └── models/video_model.pth
└── README.md                     # This file
```

## 🏗️ System Architecture

### 1. Dynamic Model Management

The service uses a three-tier model availability system:

#### Tier 1: Memory (Loaded Models)
- Models actively loaded in GPU/CPU memory
- Ready for immediate inference
- Managed by `MultiModelInferenceEngine`

#### Tier 2: Local Storage (Extracted Models)
- Models extracted and ready to load
- Located in `models/{model_name}/` directories
- Fast loading without network overhead

#### Tier 3: Central Registry (Remote Models)
- Models available for download from central repository
- Automatically downloaded and extracted on first use
- Mock implementation included for testing

### 2. Model Loading Flow

```
Frame Request → Model in Memory? → [Yes] → Generate Frame
                     ↓ [No]
              Model Extracted Locally? → [Yes] → Load into Memory
                     ↓ [No]
              Model in Local Zip? → [Yes] → Extract Model
                     ↓ [No]
              Model in Registry? → [Yes] → Download Model
                     ↓ [No]
              Return Error
```

### 3. Caching Strategy

#### Multi-Level Caching System:
- **L1 Cache**: In-memory model instances and audio features
- **L2 Cache**: Redis frame cache with model isolation
- **L3 Cache**: Redis audio feature cache (shared across models)

#### Cache Key Structure:
```
Frames:    frame:{model_name}:{frame_id}
Audio:     audio:{hash}
Metadata:  meta:{model_name}:{key}
Stats:     stats:{model_name}
```

## 🔧 Configuration

### Environment Variables

```bash
# Redis Configuration
REDIS_URL=redis://localhost:6379
REDIS_DB=0
REDIS_PASSWORD=

# Cache TTL Settings
FRAME_CACHE_TTL=3600        # 1 hour
AUDIO_CACHE_TTL=7200        # 2 hours

# Performance Settings
MAX_WORKERS=4
DEVICE=cuda                 # or 'cpu'

# Model Settings
DEFAULT_PACKAGE_PATH=./models/
CENTRAL_REPO_URL=https://api.synctalk2d.example.com/models
```

## 🚀 Quick Start

### 1. Prerequisites

```bash
# Python 3.8+
python --version

# Redis Server
redis-server --version

# CUDA (optional, for GPU acceleration)
nvidia-smi
```

### 2. Installation

```bash
# Clone repository
git clone <repository_url>
cd SyncTalk2D/fast_service

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Linux/Mac
# or
venv\Scripts\activate     # Windows

# Install dependencies
pip install -r requirements.txt
```

### 3. Start Redis

```bash
# Option 1: Local Redis
redis-server

# Option 2: Docker Redis
docker run -d -p 6379:6379 redis:alpine

# Option 3: Docker Compose (includes service)
docker-compose up -d
```

### 4. Run Service

```bash
# Development
python service.py

# Production
uvicorn service:app --host 0.0.0.0 --port 8000 --workers 4
```

### 5. Test Dynamic Loading

```bash
# Test the dynamic model system
python test_dynamic_loading.py
```

## 📡 API Reference

### Model Management

#### `GET /models`
List all loaded and locally available models.

**Response:**
```json
{
  "success": true,
  "loaded_models": ["model_a", "model_b"],
  "total_loaded": 2,
  "local_models": {
    "extracted": [{"name": "model_a", "status": "ready"}],
    "zipped": [{"name": "model_c", "status": "needs_extraction"}],
    "total": 3
  }
}
```

#### `GET /models/registry`
List models available in the central registry.

#### `POST /models/download?model_name={name}`
Manually download and extract a model from the registry.

### Frame Generation

#### `POST /generate/frame`
Generate a single frame with automatic model loading.

**Request:**
```json
{
  "model_name": "default_model",
  "frame_id": 17,
  "audio_override": "base64_encoded_audio"
}
```

**Response:**
```json
{
  "success": true,
  "model_name": "default_model", 
  "frame_id": 17,
  "frame": "base64_encoded_image",
  "from_cache": false,
  "processing_time_ms": 45,
  "auto_loaded": true
}
```

#### `POST /generate/batch`
Generate multiple frames with different audio for each frame.

**Request:**
```json
{
  "requests": [
    {"model_name": "default_model", "frame_id": 17, "audio_override": "base64_audio1"},
    {"model_name": "default_model", "frame_id": 18, "audio_override": "base64_audio2"},
    {"model_name": "enhanced_model", "frame_id": 42, "audio_override": "base64_audio3"},
    {"model_name": "fast_model", "frame_id": 99, "audio_override": "base64_audio4"},
    {"model_name": "default_model", "frame_id": 20, "audio_override": "base64_audio5"}
  ]
}
```

**Response:**
```json
{
  "success": true,
  "results": {
    "default_model_17": {
      "success": true,
      "model_name": "default_model",
      "frame_id": 17,
      "frame": "base64_encoded_image",
      "from_cache": false,
      "auto_loaded": true
    },
    "default_model_18": {
      "success": true,
      "model_name": "default_model", 
      "frame_id": 18,
      "frame": "base64_encoded_image",
      "from_cache": false,
      "auto_loaded": false
    },
    "enhanced_model_42": {
      "success": true,
      "model_name": "enhanced_model",
      "frame_id": 42, 
      "frame": "base64_encoded_image",
      "from_cache": false,
      "auto_loaded": true
    }
  },
  "total_requests": 5,
  "processed_count": 4,
  "cached_count": 1,
  "failed_count": 0,
  "auto_loaded_models": ["enhanced_model"],
  "processing_time_ms": 456
}
```

### Naming Convention: modelname_framenumber

The service supports the requested naming convention where you can think of requests as `modelname_framenumber`:

```python
# Examples:
# default_model_17  -> model_name="default_model", frame_id=17
# enhanced_model_42 -> model_name="enhanced_model", frame_id=42
# fast_model_99     -> model_name="fast_model", frame_id=99

# With audio override:
response = requests.post("http://localhost:8000/generate/frame", json={
    "model_name": "default_model",  # modelname
    "frame_id": 17,                 # framenumber
    "audio_override": encoded_audio  # <audio>
})
```

## 🎯 Usage Examples

### Basic Frame Generation

```python
import requests

# Generate a frame (model auto-loads if needed)
response = requests.post("http://localhost:8000/generate/frame", json={
    "model_name": "my_model",
    "frame_id": 17
})

result = response.json()
if result["success"]:
    # Frame is base64 encoded
    frame_data = result["frame"]
```

### Multi-Audio Batch Processing

```python
import requests
import base64

# Prepare different audio files for each frame
audio_files = ["audio1.wav", "audio2.wav", "audio3.wav", "audio4.wav", "audio5.wav"]
audio_data = []

for audio_file in audio_files:
    with open(audio_file, "rb") as f:
        encoded = base64.b64encode(f.read()).decode()
        audio_data.append(encoded)

# Batch request with different audio per frame
response = requests.post("http://localhost:8000/generate/batch", json={
    "requests": [
        {"model_name": "default_model", "frame_id": 17, "audio_override": audio_data[0]},
        {"model_name": "default_model", "frame_id": 18, "audio_override": audio_data[1]},
        {"model_name": "enhanced_model", "frame_id": 42, "audio_override": audio_data[2]},
        {"model_name": "fast_model", "frame_id": 99, "audio_override": audio_data[3]},
        {"model_name": "default_model", "frame_id": 20, "audio_override": audio_data[4]}
    ]
})

result = response.json()
if result["success"]:
    print(f"Processed {result['processed_count']} frames")
    print(f"From cache: {result['cached_count']} frames")
    print(f"Auto-loaded models: {result['auto_loaded_models']}")
    
    # Access individual results
    for key, frame_result in result["results"].items():
        if frame_result["success"]:
            print(f"Frame {key}: Generated successfully")
            frame_data = frame_result["frame"]  # base64 encoded image
        else:
            print(f"Frame {key}: Failed - {frame_result['error']}")
```

### WebSocket Streaming

```javascript
const ws = new WebSocket('ws://localhost:8000/ws');

ws.onopen = () => {
    // Request frame with auto-loading
    ws.send(JSON.stringify({
        model_name: "default_model",
        frame_id: 0
    }));
};

ws.onmessage = (event) => {
    const result = JSON.parse(event.data);
    if (result.success) {
        // Process frame
        const img = new Image();
        img.src = 'data:image/jpeg;base64,' + result.frame;
    }
};
```

## 🔍 Monitoring & Health

### Health Check
```bash
curl http://localhost:8000/health
```

### Service Status
```bash
curl http://localhost:8000/status
```

### Detailed Statistics
```bash
curl http://localhost:8000/stats
```

## 🐳 Docker Deployment

### Docker Compose

```bash
# Start all services
docker-compose up -d

# View logs
docker-compose logs -f

# Scale workers
docker-compose up -d --scale web=3
```

## 🧪 Testing

### Test Suites

```bash
# Test dynamic model loading
python test_dynamic_loading.py

# Test multi-model functionality
python test_multi_model.py
```

## 🔧 Performance Tuning

### Model Loading Optimization

1. **Pre-extract Popular Models**: Extract frequently used models to avoid extraction overhead
2. **Warm-up Cache**: Use preload endpoints to warm cache during low-traffic periods
3. **Memory Management**: Monitor model memory usage and unload unused models

### Cache Optimization

1. **TTL Tuning**: Adjust cache TTL based on usage patterns
2. **Redis Configuration**: Optimize Redis memory settings
3. **Cache Warmup**: Preload critical frames during startup

## 🛠️ Troubleshooting

### Common Issues

#### Model Download Failures
```bash
# Check model directory permissions
ls -la models/

# Check disk space
df -h
```

#### Redis Connection Issues
```bash
# Test Redis connectivity
redis-cli ping

# Check Redis logs
docker logs redis
```

## 🚦 Production Considerations

### Security

1. **Authentication**: Implement API key authentication
2. **Rate Limiting**: Add request rate limiting
3. **Input Validation**: Validate all inputs thoroughly
4. **HTTPS**: Use TLS in production

### Scalability

1. **Load Balancing**: Use nginx or similar for load balancing
2. **Redis Cluster**: Scale Redis for high availability
3. **Model Sharding**: Distribute models across multiple instances

---

**Built with ❤️ for real-time lip-sync generation**

```
┌─────────────────────┐    ┌─────────────────────┐    ┌─────────────────────┐
│   FastAPI Server    │    │  Inference Engine   │    │   Redis Cache       │
│  - REST endpoints   │ -> │  - Model in GPU      │ -> │  - Frame cache      │
│  - WebSocket        │    │  - Audio processing  │    │  - Audio features   │
│  - Request queue    │    │  - Batch processing  │    │  - Metadata         │
└─────────────────────┘    └─────────────────────┘    └─────────────────────┘
```

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Start Redis (Docker)
docker run -d -p 6379:6379 redis:alpine

# Initialize service
python service.py

# Test endpoints
curl -X POST "http://localhost:8000/initialize" \
  -H "Content-Type: application/json" \
  -d '{"package_path": "../test_advanced_package_v4.zip", "audio_path": "../demo/talk_hb.wav"}'

# Get a frame
curl "http://localhost:8000/frame/42"
```

## API Endpoints

### Core Operations
- `POST /initialize` - Load model and package
- `GET /frame/{frame_id}` - Generate single frame
- `GET /frames/batch/{start}/{end}` - Generate frame range
- `GET /health` - Service status

### Advanced Features
- `WebSocket /stream` - Real-time frame streaming
- `POST /cache/preload` - Background frame generation
- `GET /metrics` - Performance metrics

## Performance Targets

- **Cache Hit**: 5-10ms
- **Cache Miss**: 50-100ms  
- **Batch Processing**: 20-40ms per frame
- **Concurrent Requests**: 40-60 RPS
- **Memory Usage**: ~3.5GB (model + cache)

## Configuration

Environment variables:
- `REDIS_URL`: Redis connection string
- `GPU_MEMORY_LIMIT`: Maximum GPU memory usage
- `CACHE_SIZE`: Maximum cached frames
- `BATCH_SIZE`: Frames per batch operation
